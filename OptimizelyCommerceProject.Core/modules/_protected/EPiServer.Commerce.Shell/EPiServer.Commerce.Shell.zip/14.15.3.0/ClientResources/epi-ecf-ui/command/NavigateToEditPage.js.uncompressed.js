﻿define("epi-ecf-ui/command/NavigateToEditPage", [
    "dojo/_base/declare",
    "dojo/when",
    "epi/dependency",
    "epi/routes",
    "epi/shell/_ContextMixin",
    "epi/shell/TypeDescriptorManager",
    "epi-cms/component/command/ChangeContext",
    // epi-ecf-ui
    "../contentediting/ModelSupport"
],

function (
    declare,
    when,
    dependency,
    routes,
    _ContextMixin,
    TypeDescriptorManager,
    ChangeContext,
    // epi-ecf-ui
    ModelSupport
) {

    return declare([ChangeContext, _ContextMixin], {
        // summary:
        //      A command that forces browser to navigate to edit content page instead of only changing context.
        //
        // tags:
        //      public

        _hashWrapper: null,

        _contextStore: null,

        postscript: function () {
            this.inherited(arguments);
            this._contextStore = this._contextStore || dependency.resolve("epi.storeregistry").get("epi.shell.context");
            this._hashWrapper = this._hashWrapper || dependency.resolve("epi.shell.HashWrapper");
            this._routesResolver = this._routesResolver || routes;
            this._typeDescriptorManager = this._typeDescriptorManager || TypeDescriptorManager;
        },

        _execute: function () {
            // summary:
            //		Executes this command; open the edit content page in Commerce view.
            // tags:
            //		protected

            when(this._contextStore.query({ uri: this.model.uri })).then(function (context) {

                var catalogContext = context.fullHomeUrl;

                if (this._typeDescriptorManager.isBaseTypeIdentifier(context.dataType, ModelSupport.contentTypeIdentifier.catalogContentBase)) {

                    catalogContext = this._routesResolver.getActionPath({
                        moduleArea: "commerce",
                        controller: "catalog",
                        action: "",
                        id: ""
                    });
                }

                var url = catalogContext.replace(/(.{2})$/, "") + "#" + this._hashWrapper.extractHash(context);

                this._navigateTo(url);
            }.bind(this));
        },

        _navigateTo: function (url) {
            window.location = url;
        }
    });
});
