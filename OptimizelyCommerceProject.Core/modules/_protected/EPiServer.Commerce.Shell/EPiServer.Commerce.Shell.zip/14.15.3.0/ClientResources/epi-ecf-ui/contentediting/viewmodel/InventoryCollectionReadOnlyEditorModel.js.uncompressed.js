﻿define("epi-ecf-ui/contentediting/viewmodel/InventoryCollectionReadOnlyEditorModel", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    "./ReadOnlyCollectionEditorModel"
],
function (
    //dojo
    declare,
    lang,

    ReadOnlyCollectionEditorModel
) {
    return declare([ReadOnlyCollectionEditorModel], {
        // module: 
        //      epi-ecf-ui/contentediting/viewmodel/InventoryCollectionReadOnlyEditorModel
        // summary:
        //      Represents the model for InventoryCollectionReadOnlyEditor

        _storeKey: "epi.commerce.inventory",

        generateFormatters: function (columnDefinitions) {
            // summary:
            //      Resets formatter for warehouse code.
            // columnDefinitions:
            //      The definition for the columns that should get the generated formatters.
            // tags: 
            //      override

            this.inherited(arguments);

            var codeColumn = columnDefinitions.warehouseCode;
            if (codeColumn) {
                codeColumn.formatter = function (value) {
                    return value;
                };
            }

            return columnDefinitions;
        }
    });
});