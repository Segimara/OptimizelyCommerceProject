define("epi-ecf-ui/widget/MoveDiscountDialog", [
    "dojo/_base/declare",
    "dojo/dom-geometry",
    "dojo/dom-style",
    "dojo/string",
    // epi
    "epi/shell/widget/dialog/Dialog",
    "./MoveDiscountDialogContent",
    // resources
    "epi/i18n!epi/nls/commerce.widget.movediscountdialog"
],
function (
    declare,
    domGeometry,
    domStyle,
    dojoString,
    // epi
    Dialog,
    MoveDiscountDialogContent,
    // resources
    resources
) {

    return declare([Dialog], {
        // summary:
        //		A custom dialog Widget for Move Discount function
        //
        // description:
        //		Pops up a modeless dialog window in top right
        //
        // tags:
        //      public

        confirmActionText: resources.okbutton,
        heading: resources.heading,
        description: resources.description,
        discountLink: null,

        constructor: function() {
            this.inherited(arguments);

            this.content = new MoveDiscountDialogContent();

            this.own(
                this.content.on("move-option-changed", function (evt) {
                    this.enableActionButton(evt.isValid);
                }.bind(this))
            );

            this.content.setExcludedLink(this.discountLink);
        },

        // overrided
        _size: function () {
            this.inherited(arguments);
            domStyle.set(this.containerNode, "overflow", "auto");
        },

        // overrided
        _position: function () {
            domStyle.set(this.domNode, {
                right: "0px",
                top: "0px"
            });
        },

        // overrided
        show: function() {
            this.inherited(arguments);
            this.enableActionButton(false);
        },

        enableActionButton: function (enable) {
            this.onActionPropertyChanged({ name: this._okButtonName }, "disabled", !enable);
        },

        updateDescriptionForDialog: function(name) {
            this.descriptionNode.innerText = dojoString.substitute(resources.description, { discountName: name});
        },

        resize: function(newHeight) {
            var titleHeight = domGeometry.getMarginBox(this.titleBar).h;
            var actH = domGeometry.getMarginBox(this.actionContainerNode).h;
            var headingH = domGeometry.getMarginBox(this.headingNode).h;
            var descH = domGeometry.getMarginBox(this.descriptionNode).h;
            var containerNodeHeight = newHeight - (titleHeight + actH + headingH + descH);
            domGeometry.setContentSize(this.containerNode, { h: containerNodeHeight });
        }
    });
});
