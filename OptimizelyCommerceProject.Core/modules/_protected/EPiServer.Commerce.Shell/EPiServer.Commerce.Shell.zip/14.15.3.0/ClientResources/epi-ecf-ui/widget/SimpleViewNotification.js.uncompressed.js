﻿define("epi-ecf-ui/widget/SimpleViewNotification", [
    "dojo/_base/declare",
    "dojo/dom-construct",
    "dojo/Stateful",
    "dojo/topic",
    "epi/i18n!epi/cms/nls/commerce.widget.simpleview"
], function (
    declare,
    domConstruct,
    Stateful,
    topic,
    resources
) {
    return declare([Stateful], {

        notification: null,

        updateNotification: function (context) {
            if (!!context && !!context.capabilities && !!context.capabilities.sortChildren) {
                this.set("notification", {});
                return;
            }

            var notificationText = domConstruct.create("div", {
                innerHTML: resources.notificationtext
            });

            this.set("notification", {
                content: notificationText
            });
        }
    });
});