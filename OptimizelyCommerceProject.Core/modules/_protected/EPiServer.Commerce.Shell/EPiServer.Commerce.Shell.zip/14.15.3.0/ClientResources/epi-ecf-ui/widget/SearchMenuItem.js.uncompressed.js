define("epi-ecf-ui/widget/SearchMenuItem", [
    "dojo/_base/declare",
    "dojo/dom",
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/_Contained",
    "epi/shell/widget/SearchBox",
    "epi/i18n!epi/nls/commerce.widget.movediscountdialog"
], function (declare, dom, _WidgetBase, _TemplatedMixin, _Contained, SearchBox, resources) {

    return declare([_WidgetBase, _TemplatedMixin, _Contained], {
        // summary:
        //		A grouping element for menu items
        // tags:
        //      internal

        baseClass: "dijitMenuItemGroup epi-marketing-searchmenuitem",

        templateString: "<tr class=\"dijitMenuItemGroup\"><td colspan=\"4\" data-dojo-attach-point=\"containerNode\"></td></tr>",

        isSearchMenu: true,

        _searchBox: null,

        // label: String
        //     Group display text
        _setLabelAttr: { node: "containerNode", type: "innerHTML" },

        buildRendering: function () {
            this.inherited(arguments);
            dom.setSelectable(this.domNode, false);
        },

        postCreate: function() {
            this.inherited(arguments);

            this._searchBox = this._searchBox || new SearchBox({
                baseClass: "epi-search--full-width",
                onSearchBoxChange: this.onSearchBoxChange.bind(this),
                onKeyDown: function (e) {
                    if (e.keyCode === 32) {
                        this.set('value', this.get('value') + ' ');
                    }
                }
            });
            this._searchBox._setPlaceHolderAttr(resources.searchplaceholder);
            this._searchBox.placeAt(this.containerNode);
        },

        onSearchBoxChange: function(queryText) {
            this.emit("searchtext", { queryText: queryText });
        },

        _setPlaceHolderAttr: function(text) {
            if (this._searchBox) {
                this._searchBox._setPlaceHolderAttr(text);
            }
        }
    });
});
