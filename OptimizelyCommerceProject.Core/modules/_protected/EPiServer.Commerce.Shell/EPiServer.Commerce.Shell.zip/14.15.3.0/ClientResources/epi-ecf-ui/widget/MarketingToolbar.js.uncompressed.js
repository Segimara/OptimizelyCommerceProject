define("epi-ecf-ui/widget/MarketingToolbar", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/topic",
    "dojo/when",
    "dijit/Destroyable",
    "epi/shell/widget/ToolbarSet",
    "dijit/form/Button",
// epi-ecf-ui
    "../MarketingUtils",
    "epi/i18n!epi/nls/commerce.widget.marketingtoolbar",
    "epi/i18n!epi/nls/episerver.shared",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting"
], function (declare,
    lang,
    topic,
    when,
    Destroyable,
    ToolbarSet,
    Button,
// epi-ecf-ui
    MarketingUtils,
    resources,
    sharedResource,
    toggleResources
) {
    var _ToggleAssetsPaneCommand = declare([Button, Destroyable], {
        iconClass: "epi-iconFolder",
        region: "trailing",
        "class": "epi-trailingToggleButton epi-mediumButton",
        showLabel: false,
        tooltip: toggleResources.toolbar.buttons.toggleassetspane,
        title: toggleResources.toolbar.buttons.toggleassetspane,
        _onClick: function () {
            this.inherited(arguments);
            topic.publish("/epi/layout/pinnable/tools/toggle");
        }
    });

    return declare([ToolbarSet], {
        // tags:
        //      public

        // currentContext: [public] Object
        //      An object with the current context information.
        currentContext: null,

        resources: resources,

        // _setupPromise: [private] String
        //      The setup children promise.
        _setupPromise: null,

        groupNames: {
            leading: "leading",
            center: "center",
            trailing: "trailing"
        },

        buttonNames: {
            saveButton: "saveButton",
            closeButton: "closeButton"
        },

        viewName: null,

        buildRendering: function () {
            // summary:
            //      Constructs the toolbar container and starts the children setup process.
            // tags:
            //      protected

            this.inherited(arguments);

            // Setup the children items in the toolbar.
            // Update the toolbar items with the current model.
            when(this._setupPromise = this.setupChildren(), this.updateChildren.bind(this));
        },

        isSetup: function () {
            // summary:
            //      Wait for setup to finish.
            // tags:
            //      protected

            return this._setupPromise;
        },

        setupChildren: function () {
            // summary:
            //      Setup the items in the toolbar. Inheriting classes should extend this to add more items to the toolbar.
            // tags:
            //      protected

            var toolbarGroups = [
                {
                    name: this.groupNames.leading,
                    type: "toolbargroup",
                    settings: { region: "leading" }
                },
                {
                    name: this.groupNames.center,
                    type: "toolbargroup",
                    settings: { region: "center" }
                },
                {
                    name: this.groupNames.trailing,
                    type: "toolbargroup",
                    settings: { region: "trailing" }
                }];

            var toolbarItems = [];
            if (this.viewName === "marketingdetail") {
                toolbarItems.push(
                    {
                        parent: this.groupNames.leading,
                        name: "breadcrumbs",
                        widgetType: "epi-cms/widget/Breadcrumb",
                        settings: {
                            displayAsText: false,
                            showCurrentNode: false
                        }
                    },
                    {
                        parent: this.groupNames.leading,
                        name: "currentcontent",
                        widgetType: "epi-cms/widget/BreadcrumbCurrentItem"
                    },
                    {
                        parent: this.groupNames.center,
                        name: "notifications",
                        widgetType: "epi-cms/widget/NotificationStatusBar"
                    }
                );

                var toggleAsset = new _ToggleAssetsPaneCommand();
                this.addChild(toggleAsset);
            }

            if (this.viewName === "marketingoverview") {
                toolbarItems.push(
                    {
                        parent: this.groupNames.trailing,
                        name: "viewselect",
                        label: this.resources.discountpriorityview.title,
                        widgetType: "dijit/form/Button",
                        settings: {
                            showLabel: true,
                            "class": "epi-marketing-button epi-marketing-button__secondary"
                        },
                        action: function () {
                            setTimeout(function () {
                                topic.publish("/epi/shell/action/changeview", "discountpriorityview", {}, { sender: this });
                            }.bind(this), 0);
                        }
                    },
                    {
                        parent: this.groupNames.trailing,
                        name: "createNewDropdown",
                        label: "Create New...",
                        widgetType: "epi-ecf-ui/widget/CreateNewMarketing",
                        settings: {
                            showLabel: false,
                            "class": "epi-marketing-button epi-marketing-button__primary"
                        }
                    }
                );
            }

            return this.add(toolbarGroups).then(function () {
                this.add(toolbarItems);
                return;
            }.bind(this));

        },

        updateChildren: function () {
            // summary:
            //      Update the toolbar items. This method is called on startup and whenever the current context is set.
            // tags:
            //      protected

            var context = this.currentContext,
                contentLink = context && context.id;

            this.setItemProperty("breadcrumbs", "contentLink", contentLink);
            this.setItemProperty("viewselect", "viewConfigurations", this.viewConfigurations);
            this.setItemProperty(
                "notifications",
                "notificationContext",
                { contextTypeName: "epi.cms.contentdata", contextId: contentLink });

            if (context) {
                this.setItemProperty("currentcontent", "currentItemInfo", {
                    name: context.dataType === MarketingUtils.contentTypeIdentifier.campaignFolder ? null : context.name,
                    dataType: context.dataType
                });
            }
        },

        update: function (data) {
            // summary:
            //      Update the toolbar with new data.
            // data:
            //      Toolbar data model. Expected properties are: currentContext
            // tags:
            //      public

            if (!data) {
                return;
            }

            this.currentContext = data.currentContext;
            this.viewConfigurations = data.viewConfigurations;

            when(this.isSetup(), this.updateChildren.bind(this));
        },

        getActionButtons: function () {
            // summary:
            //      Gets the action buttons definition.
            // tags:
            //      public

            var buttonDefinition = {
                parent: this.groupNames.trailing,
                type: "button"
            };

            return {
                save: lang.mixin({
                    name: this.buttonNames.saveButton,
                    label: sharedResource.action.save,
                    settings: { disabled: true, "class": "epi-button--bold" }
                }, buttonDefinition),
                close: lang.mixin({
                    name: this.buttonNames.closeButton,
                    label: sharedResource.action.close,
                    settings: { "class": "epi-button--bold" }
                }, buttonDefinition)
            };
        },

        updateActionButtonStatus: function (buttonName, enabled) {
            // summary:
            //      Update state of action button
            // tags:
            //      Public
            this.setItemProperty(buttonName, "class", "epi-button--bold" + (enabled ? " epi-primary" : ""));
            this.setItemProperty(buttonName, "disabled", !enabled);
        }
    });
});