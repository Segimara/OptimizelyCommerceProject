require({cache:{
'url:epi-cms/widget/templates/CreateInlineBlock.html':"<div class=\"epi-createInlineBlock\">\r\n    <div class=\"epi-namePanel dijitHidden\" data-dojo-attach-point=\"namePanel\">\r\n        <label>\r\n            ${createBlockRes.name}\r\n        </label>\r\n        <input data-dojo-attach-point=\"nameTextBox\"\r\n               data-dojo-type=\"dijit/form/ValidationTextBox\"\r\n               data-dojo-props=\"selectOnClick: true, trim:true\"\r\n               maxlength=\"255\" />\r\n    </div>\r\n    <div>\r\n        <div data-dojo-attach-point=\"contentTypeList\"></div>\r\n        <div data-dojo-attach-point=\"propertiesForm\"></div>\r\n    </div>\r\n</div>\r\n"}});
define("epi-cms/contentediting/command/ContentAreaItemBlockEdit", [
    "dojo/_base/declare",
    "dojo/on",
    "dojo/topic",
    "dojo/when",
    "dojo/Evented",

    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/layout/_LayoutWidget",

    "dojox/html/entities",

    "epi/dependency",
    "epi/shell/DestroyableByKey",
    "epi/shell/TypeDescriptorManager",

    "epi/shell/command/_Command",

    "epi-cms/contentediting/DialogPositionAdjust",
    "epi-cms/contentediting/inline-editing/InlineEditBlockDialog",
    "epi-cms/contentediting/inline-editing/LocalBlockEditFormContainer",
    "epi-cms/_ContentContextMixin",
    "epi-cms/ApplicationSettings",

    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.inlineediting",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.toolbar.buttons",
    "epi/i18n!epi/nls/episerver.cms.contentapproval.command.requestapproval",

    "dojo/text!./../../widget/templates/CreateInlineBlock.html",
    "epi/i18n!epi/cms/nls/episerver.shared.action",
    "epi/i18n!epi/cms/nls/episerver.cms.components.createblock"
], function (
    declare,
    on,
    topic,
    when,
    Evented,

    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    _LayoutWidget,

    htmlEntities,

    dependency,
    DestroyableByKey,
    TypeDescriptorManager,

    _Command,

    DialogPositionAdjust,
    InlineEditBlockDialog,
    LocalBlockEditFormContainer,
    _ContentContextMixin,
    applicationSettings,
    resources,
    toolbarButtonsRes,
    requestapprovalRes,

    template,
    actionStrings,
    createBlockRes
) {

    var EditInlineBlock = declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, Evented], {
        templateString: template,

        createBlockRes: createBlockRes,

        postCreate: function () {
            this.inherited(arguments);

            this.own(this.nameTextBox.on("keyup", function () {
                this.emit("change", this.getName());
            }.bind(this)));
        },

        getName: function () {
            return this.nameTextBox.get("value");
        },

        setName: function (name) {
            this.nameTextBox.set("value", name);

            if (!this.readOnly) {
                this.nameTextBox.focus();
                this.nameTextBox.textbox.select();
            }
        },

        setReadOnly: function (readOnly) {
            this.readOnly = readOnly;
            this.nameTextBox.set("readOnly", readOnly);
        }
    });

    return declare([_Command, Evented, DestroyableByKey, _ContentContextMixin], {
        // summary:
        //      Inline-edit command for local ContentArea blocks stored in ContentArea
        // tags:
        //      internal xproduct

        label: resources.inlineblockedit,

        iconClass: "epi-iconPenQuick",

        isContentAreaReadonly: false,

        // suppressOverlayAdjustments: [public] Boolean
        //      Flag which indicates that all overlay adjustments should not be performed. It might be useful when showing another overlay or dialog (e.g. TinyMCE full screen)
        suppressOverlayAdjustments: false,

        postscript: function () {
            this.inherited(arguments);

            this._dialogPositionAdjust = new DialogPositionAdjust();
            this.own(this._dialogPositionAdjust);
        },

        _execute: function () {
            // summary:
            //    Open the inline edit block dialog
            // tags:
            //      protected

            var blockName = htmlEntities.encode(this.model.name);
            var dialog = new InlineEditBlockDialog({
                title: blockName,
                mainCommand: this.mainCommand,
                suppressOverlayAdjustments: this.suppressOverlayAdjustments
            });

            var editInlineBlock;
            var form;
            var newName = blockName;

            function updateMainCommandVisibility() {
                if (!dialog) {
                    return;
                }
                dialog.toggleDisabledSaveButton(!form.get("isDirty") && (!newName || newName === blockName));
            }

            editInlineBlock = new EditInlineBlock({}, dialog.content, "last");

            var typeName = TypeDescriptorManager.getTypeNameFromTypeId(this.model.contentTypeId);
            if (typeName && !Object.prototype.hasOwnProperty.call(applicationSettings.inlineBlockNameProperties, typeName.toLowerCase())) {
                editInlineBlock.setReadOnly(this.isContentAreaReadonly);
                editInlineBlock.setName(blockName);
                editInlineBlock.namePanel.classList.remove("dijitHidden");
            }

            this.own(editInlineBlock.on("change", function (name) {
                newName = name;
                updateMainCommandVisibility();
            }.bind(this)));

            form = new LocalBlockEditFormContainer({});
            dialog.own(form);

            this._getMetadata(this.model.contentTypeId).then(function (metadata) {
                form.set("contentLink", this.parentContentLink);
                // We need to set the form value before the form emits `FormCreated` to ensure the initial value of the form is correct.
                form.set("value", this.model.inlineBlockData);
                when(form.set("metadata", metadata)).then(function () {
                    form.placeAt(editInlineBlock.propertiesForm);
                }.bind(this));
            }.bind(this));

            if (this.model.get("readOnly")) {
                form.set("readOnly", true);
            }

            dialog.own(on(form, "FormCreated", function () {
                if (form.model && !form._model.canChangeContent()) {
                    dialog.hideSaveButton();
                    dialog.set("closeText", "Close");
                }

                dialog.show();
                this._positionDialogOnTopOfMainContent(dialog);
                updateMainCommandVisibility();
            }.bind(this)));

            dialog.own(on(form, "isDirty", updateMainCommandVisibility.bind(form)));
            dialog.own(on(dialog, "execute", function () {
                this.emit("save", form.get("value"), newName || this.model.contentTypeName);
            }.bind(this)));

            dialog.own(on(dialog, "hide", function () {
                this._dialogPositionAdjust.cleanup();
            }.bind(this)));

            this.own(dialog);
            this._dialogPositionAdjust.adjustDialogPosition(dialog);
        },

        _positionDialogOnTopOfMainContent: function (dialog) {
            // summary:
            //      Content Types List will cover the main editing area with some small padding
            //
            // dialog:
            //      Dialog which will cover the editing area
            //
            // tags:
            //      private

            var mainContent = document.querySelector(".epi-main-content");
            if (mainContent) {
                var dimensions = mainContent.getBoundingClientRect();
                var padding = 40;
                dialog.domNode.style.left = dimensions.left + padding + "px";
                dialog.domNode.style.top = dimensions.top + padding + "px";
                dialog.domNode.style.width = dimensions.width - 2 * padding + "px";
                dialog.domNode.style.maxWidth = 880 + "px";
            }
        },

        _getMetadata: function (contentTypeId) {
            return when(this.getCurrentContent()).then(function (content) {
                this.parentContentLink = content.contentLink;
                this.metadataManager = this.metadataManager || dependency.resolve("epi.shell.MetadataManager");
                return this.metadataManager.getMetadataForType("EPiServer.Core.ContentData", {
                    parentLink: content.contentLink,
                    contentTypeId: contentTypeId
                });
            }.bind(this));
        },

        updateModel: function (model) {
            // summary:
            //      Updates model and returns result from onModelChange callback
            // tags:
            //      internal

            this.model = model;
            return this._onModelChange();
        },

        _onModelChange: function () {
            // summary:
            //      Updates isAvailable after the model has been updated.
            // tags:
            //      protected

            this.inherited(arguments);

            var item = this.model;

            if (!item || !item.inlineBlockData) {
                this.set("isAvailable", false);
                return;
            }

            this.set("canExecute", true);
            this.set("isAvailable", true);

            if (this.model instanceof Array) {
                // this command should be available only if one item selected
                // because it should be disabled when multiple blocks are selected
                // like in Assets pane
                if (this.model.length === 1) {
                    this.model = this.model[0];
                } else {
                    this.model = null;
                }
            }

            if (!this.model) {
                this.set("canExecute", false);
                return;
            }

            if (this.model.isOverlayInitialized === false) {
                return;
            }

            if (!this.isContentAreaReadonly) {
                this.set("label", actionStrings.edit);
                this.set("iconClass", "epi-iconPen");
            } else {
                this.set("label", actionStrings.view);
                this.set("iconClass", "epi-iconSearch");
            }
        }
    });
});
